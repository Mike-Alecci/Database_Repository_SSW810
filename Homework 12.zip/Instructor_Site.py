from flask import Flask, render_template
import sqlite3

app = Flask(__name__)

@app.route('/instructor_table')
def create_instructor_table():
    sqlite_file = 'HW11DB.db'
    query = """select i.CWID, i.Name, i.Dept, g.Course, count(*) as Number_Students from Instructors i
                join grades g on i.CWID = g.Instructor_CWID group by g.course order by Number_Students desc"""
    conn = sqlite3.connect(sqlite_file)
    c = conn.cursor()
    c.execute(query)
    results = c.fetchall()
    # convert the query results into a list of dictionaries to pass to the template
    data = [{'cwid': cwid, 'name': name, 'dept': dept, 'course': course, 'students': num_stud}
            for cwid, name, dept, course, num_stud in results]
    conn.close()  # close the connection to close the database
    return render_template('instructor_table.html',
                           title='Stevens Data Repository',
                           table_title="Instructor Information",
                           students=data)

app.run(debug=True)